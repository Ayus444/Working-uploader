echo "starting Bot ~@DroneBots";
python3 -m main
